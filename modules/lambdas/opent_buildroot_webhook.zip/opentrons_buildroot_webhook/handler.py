"""
handler.py: AWS Lambda function fusing GH webhooks from monorepo and buildroot

This will be deployed to a lambda and installed as a webhook both in the
opentrons monorepo and opentrons buildroot repo on github. It will be used to
trigger builds in buildroot based on pushes to both the monorepo and BR.
"""

import binascii
import hmac
import hashlib
import json
import logging
import os
import re
from typing import Any, Callable, Mapping, NamedTuple, Tuple


from github import Github  # type: ignore
from github.GithubException import GithubException  # type: ignore

MODULE_LOG = logging.getLogger('opentrons_buildroot_webhook')
MODULE_LOG.setLevel(getattr(logging,
                            os.environ.get('LOG_LEVEL', 'info').upper(),
                            'INFO'))
# matches refs/tags/v3.12.0-alpha.0 but not refs/tags/protocol-designer@1.2.3
TAG_PAT = re.compile(r'^refs/tags/v\d+.*')

SSM_CLIENT = None
CODEBUILD_CLIENT = None


class Buildspec(NamedTuple):
    """ Data bundle for starting a build """
    buildroot_ref: str
    monorepo_ref: str
    is_release: bool


def get_parameter(param_name: str) -> str:
    """ Pull a parameter from SSM.

    The param name should be the name of the right-most part of the path;
    this function will add the app-name/app-stage/function-name boilerplate
    """
    # Using the global statement here to cache boto3 clients in the lambda
    # environment
    global SSM_CLIENT  # pylint: disable=global-statement
    if not SSM_CLIENT:
        # pylint: disable=import-outside-toplevel
        import boto3  # type: ignore
        SSM_CLIENT = boto3.client('ssm')

    path = '/' + '/'.join([os.getenv('APP_NAME', 'unknown-name'),
                           os.getenv('APP_STAGE', 'unknown-stage'),
                           'opentrons-buildroot-webhook',
                           param_name])
    MODULE_LOG.debug(f"Getting parameter {path}")
    resp = SSM_CLIENT.get_parameter(
        Name=path,
        WithDecryption=True
    )
    return resp['Parameter']['Value']


def resolve_to_sha(repo: str, branch: str) -> str:
    """ Resolve a nice branch ref to a SHA if possible

    If it can't be resolved, we'll just return the branch ref.
    """
    gh_api = Github(get_parameter('GITHUB_ACCESS_TOKEN'))
    try:
        resolved = gh_api.get_repo(repo)\
                         .get_branch(branch)\
                         .commit.sha
        MODULE_LOG.info(f"Resolved {repo} branch {branch} to {resolved}")
        return resolved
    except GithubException:
        MODULE_LOG.warning(f"Couldn't resolve {repo} branch {branch}")
        return branch


def start_build(configuration: Buildspec) -> Tuple[int, str]:
    """ Start a build on codebuild using the passed refs.

    configuration should be the result of configure_build or similar.

    Returns (code, message)
    """
    # Using the global statement here to cache boto3 clients in the lambda
    # environment
    global CODEBUILD_CLIENT  # pylint: disable=global-statement
    if not CODEBUILD_CLIENT:
        # pylint: disable=import-outside-toplevel
        import boto3  # type: ignore
        CODEBUILD_CLIENT = boto3.client('codebuild')

    # Pre-resolve to a hash for opentrons since it’s a secondary source

    monorepo_resolved = resolve_to_sha('Opentrons/opentrons', configuration.monorepo_ref)
    br_resolved = resolve_to_sha('Opentrons/buildroot', configuration.buildroot_ref)
    build_type = 'release' if configuration.is_release else 'dev'
    id_token = hashlib.sha256(
        (monorepo_resolved + br_resolved + build_type).encode()).hexdigest()[:64]
    MODULE_LOG.info(f"Starting build {configuration}")
    CODEBUILD_CLIENT.start_build(
        projectName='opentrons-buildroot',
        sourceVersion=configuration.buildroot_ref,
        secondarySourcesVersionOverride=[{
            'sourceIdentifier': 'Monorepo',
            'sourceVersion': configuration.monorepo_ref
        }],
        idempotencyToken=id_token,
        environmentVariablesOverride=[{
            'name': 'OT_BUILD_TYPE',
            'value': build_type,
            'type': 'PLAINTEXT'
        }]
    )

    return (200, 'Build started')


def has_branch(repo_name: str, branch_name: str) -> bool:
    """ Query github to see if repo_name has branch branch_name """
    gh_api = Github(get_parameter('GITHUB_ACCESS_TOKEN'))
    repo = gh_api.get_repo(f'Opentrons/{repo_name}')
    try:
        repo.get_branch(branch_name)
    except GithubException as ghe:
        if ghe.status == 404:
            return False
        else:
            raise
    else:
        return True


def get_latest_release(repo_name: str) -> str:
    """
    Get the most recent release of the repo and return its ref.
    """
    gh_api = Github(get_parameter('GITHUB_ACCESS_TOKEN'))
    repo = gh_api.get_repo(f'Opentrons/{repo_name}')
    release = repo.get_latest_release()
    return release.tag_name


def validate_webhook(
        headers: Mapping[str, str], body: str) -> Mapping[str, Any]:
    """
    Validate that the request we received is a good webhook and parse body

    This will check that required headers are present, validate the hash
    header, and decode the body.
    """
    # Basic checks that this is from github and is json
    assert 'x-github-event' in headers
    assert headers['content-type'].startswith('application/json')

    # Load the body so we can check the originating repo
    body_dict = json.loads(body)
    repo_name = body_dict['repository']['name']
    assert repo_name in ('opentrons', 'buildroot')

    # Check the signature using a secret based on the repo name
    assert 'x-hub-signature' in headers
    secret_name = repo_name.upper() + '_GITHUB_WEBHOOK_SECRET'
    secret = get_parameter(secret_name)
    hash_alg, hash_out = headers['x-hub-signature'].split('=')
    local_hash = binascii.hexlify(
        hmac.digest(secret.encode(), body.encode(), hash_alg)).decode()
    assert local_hash == hash_out, 'Message signature mismatch!'
    MODULE_LOG.info(f"Good hook received from {repo_name}")
    return body_dict


def configure_build(hook_repo: str, hook_branch: str) -> Buildspec:
    """
    Core business logic of the handler as documented in README.

    hook_repo should be the short name of the repo that sent the hook
    (e.g. opentrons not Opentrons/opentrons) and hook_branch should be the
    ref in the hook (refs/heads/edge not edge)

    If no matching branch is found, raises KeyError.

    If a matching branch is found, its porcelain name (e.g. 'edge' not
    'refs/heads/edge') is returned along with a bool specifying whether the
    build is release (True) or isn't release (False)
    """
    hook_branch_porcelain = hook_branch.split('/')[-1]
    if hook_repo == 'buildroot':
        if hook_branch_porcelain == 'opentrons-develop':
            # fast case: no GH api call required
            MODULE_LOG.info("BR opentrons-develop, force edge")
            return Buildspec(buildroot_ref=hook_branch_porcelain,
                             monorepo_ref='edge',
                             is_release=False)
        elif has_branch('opentrons', hook_branch_porcelain):
            # use a matching branch of the monorepo has one
            MODULE_LOG.info("BR matches monorepo")
            return Buildspec(buildroot_ref=hook_branch_porcelain,
                             monorepo_ref=hook_branch_porcelain,
                             is_release=False)
        else:
            # otherwise fall back to edge
            MODULE_LOG.info("BR fallback to edge")
            return Buildspec(buildroot_ref=hook_branch_porcelain,
                             monorepo_ref='edge',
                             is_release=False)
    else:
        # hook_repo is opentrons (verified in validate_webhook)
        if TAG_PAT.match(hook_branch):
            MODULE_LOG.info("Monorepo tag build, finding br tag")
            # This is a release. Find a matching tag in buildroot
            return Buildspec(buildroot_ref=get_latest_release('buildroot'),
                             monorepo_ref=hook_branch_porcelain,
                             is_release=True)
        elif hook_branch.startswith('refs/tags'):
            MODULE_LOG.info(f"Tag {hook_branch_porcelain} not for us")
            raise KeyError(hook_branch)
        elif hook_branch_porcelain == 'edge':
            # fast case: no GH api call required
            MODULE_LOG.info("Monorepo edge build, force opentrons-develop")
            return Buildspec(buildroot_ref='opentrons-develop',
                             monorepo_ref=hook_branch_porcelain,
                             is_release=False)
        elif has_branch('buildroot', hook_branch_porcelain):
            # use a matching branch if buildroot has one
            MODULE_LOG.info("Monorepo matches BR")
            return Buildspec(buildroot_ref=hook_branch_porcelain,
                             monorepo_ref=hook_branch_porcelain,
                             is_release=False)
        else:
            # no build
            MODULE_LOG.info(f"No match for monorepo branch {hook_branch}")
            raise KeyError(hook_branch)


def handle_push(body: Mapping[str, Any]) -> Tuple[int, str]:
    """ Handler for a github push event """
    this_ref = body['ref']
    this_branch = this_ref.split('/')[-1]
    this_repo_name = body['repository']['name']
    other_repo_name = {'opentrons': 'buildroot',
                       'buildroot': 'opentrons'}[this_repo_name]
    MODULE_LOG.info(f"Received push for {this_repo_name} ref {this_ref}")
    try:
        to_build = configure_build(this_repo_name, this_ref)
    except KeyError:
        message = f'Hook OK but no match found in {other_repo_name} for '\
            f'branch {this_branch}'
        MODULE_LOG.info(message)
        return (200, message)
    return start_build(to_build)


def handle_ping(body: Mapping[str, Any]) -> Tuple[int, str]:
    """ Handler for a github ping event """
    MODULE_LOG.info(
        f"Received ping for hook {body['hook_id']} from "
        f"{body['repository']['full_name']}")
    return (200, 'pong')


# Handlers take the deep json dict of the request body and return
# a tuple of (HTTP error code, short message)
Handler = Callable[[Mapping[str, Any]], Tuple[int, str]]

event_dispatch: Mapping[str, Handler] = {
    "ping": handle_ping,
    "push": handle_push,
}


def dispatch_webhook(
        headers: Mapping[str, Any], decoded_body: Mapping[str, Any])\
        -> Tuple[int, str]:
    """ Dispatch validated webhooks to handlers based on the event """
    evt_type = headers['x-github-event']
    MODULE_LOG.info(f"Received webhook {evt_type}")

    try:
        handler = event_dispatch[evt_type]
    except KeyError:
        MODULE_LOG.warning(f"hook for unsupported event {evt_type} received")
        return (400, f'Unsupported webhook event type {evt_type}')

    return handler(decoded_body)


def build_apigateway_response(
        error_code: int, message: str) -> Mapping[str, Any]:
    """ Format a (code, message) into an APIGateway json dict """
    return {
        'isBase64Encoded': False,
        'statusCode': error_code,
        'body': message
    }


def handle_webhook(event, context):  # pylint: disable=W0613
    """ Main entrypoint. Passed the event and ctx from serverless. """

    # Disabling pylint broad exceptions here because these are top
    # level catchalls that log the exceptions and format the output
    lcase_headers = {k.lower(): v for k, v in event['headers'].items()}
    try:
        body = validate_webhook(lcase_headers, event['body'])
    except AssertionError:
        MODULE_LOG.exception("Bad webhook")
        return build_apigateway_response(400, 'Bad request')
    except Exception:  # pylint: disable=broad-except
        MODULE_LOG.exception("Failed to validate webhook")
        return build_apigateway_response(500, '')

    try:
        return build_apigateway_response(
            *dispatch_webhook(lcase_headers, body))
    except Exception:  # pylint: disable=broad-except
        MODULE_LOG.exception("Failed to  dispatch webhook")
        return build_apigateway_response(500, '')
