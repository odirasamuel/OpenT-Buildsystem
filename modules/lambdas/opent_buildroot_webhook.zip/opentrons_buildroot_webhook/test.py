import unittest
from unittest.mock import Mock

import handler


class TestHandler(unittest.TestCase):
    def setUp(self):
        self.old_methods = {}
        for meth in ('get_parameter',
                     'start_build',
                     'has_branch',
                     'get_latest_release'):
            self.old_methods[meth] = getattr(handler, meth, None)
            setattr(handler, meth, Mock())

    def tearDown(self):
        for meth_name, meth in self.old_methods.items():
            setattr(handler, meth_name, meth)

    def test_matching_branch(self):
        handler.has_branch.return_value = True
        branch_name = 'some_branch_name'
        for repo_names in [('opentrons', 'buildroot'),
                           ('buildroot', 'opentrons')]:
            self.assertEqual(
                handler.configure_build(repo_names[0],
                                        'refs/heads/' + branch_name),
                handler.Buildspec(monorepo_ref=branch_name,
                                  buildroot_ref=branch_name,
                                  is_release=False))
        handler.has_branch.assert_called_with(repo_names[1],
                                              branch_name)

    def test_special_branches(self):
        self.assertEqual(
            handler.configure_build('opentrons', 'refs/heads/edge'),
            handler.Buildspec(monorepo_ref='edge',
                              buildroot_ref='opentrons-develop',
                              is_release=False))
        handler.has_branch.assert_not_called()
        self.assertEqual(
            handler.configure_build(
                'buildroot', 'refs/heads/opentrons-develop'),
            handler.Buildspec(monorepo_ref='edge',
                              buildroot_ref='opentrons-develop',
                              is_release=False))
        handler.has_branch.assert_not_called()

    def test_no_match(self):
        handler.has_branch.return_value = False
        self.assertEqual(
            handler.configure_build('buildroot', 'refs/heads/no-such-branch'),
            handler.Buildspec(monorepo_ref='edge',
                              buildroot_ref='no-such-branch',
                              is_release=False))
        handler.has_branch.assert_called_with('opentrons', 'no-such-branch')
        self.assertRaises(KeyError, handler.configure_build,
                          'opentrons', 'refs/heads/no-such-branch')

    def test_handle_push_ok(self):
        handler.has_branch.return_value = True
        branchname = 'dummy-branch-blahblahblah'
        handler.handle_push({'ref': f'refs/heads/{branchname}',
                             'repository': {'name': 'opentrons'}})
        handler.start_build.assert_called_with(
            handler.Buildspec(monorepo_ref=branchname,
                              buildroot_ref=branchname,
                              is_release=False))

    def test_handle_push_no_build(self):
        handler.has_branch.return_value = False
        branchname = 'dummy-branch-blashdasbdl'
        ret = handler.handle_push({'ref': f'refs/heads/{branchname}',
                                   'repository': {'name': 'opentrons'}})
        self.assertEqual(ret[0], 200)
        handler.start_build.assert_not_called()

    def test_tag(self):
        handler.get_latest_release.return_value = 'v0.1.0'
        self.assertEqual(
            handler.configure_build('opentrons', 'refs/tags/v3.5.0'),
            handler.Buildspec(monorepo_ref='v3.5.0',
                              buildroot_ref='v0.1.0',
                              is_release=True))
        self.assertRaises(
            KeyError,
            handler.configure_build,
            'opentrons', 'refs/tags/protocol-designer@1.2.3')

        self.assertEqual(
            handler.configure_build('opentrons', 'refs/tags/v3.5.0-alpha.0'),
            handler.Buildspec(monorepo_ref='v3.5.0-alpha.0',
                              buildroot_ref='v0.1.0',
                              is_release=True))
        self.assertEqual(
            handler.configure_build(
                'opentrons', 'refs/tags/v43.75.0123-beta.1'),
            handler.Buildspec(monorepo_ref='v43.75.0123-beta.1',
                              buildroot_ref='v0.1.0',
                              is_release=True))


if __name__ == '__main__':
    unittest.main()
